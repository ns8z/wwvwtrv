import WebSocket from 'ws';

let Bot = {
    Count: 1,
    Tokens: []
}
class ProPeanut {
    constructor() {

    }
    static tok(token){
        Bot.Tokens.push(token)
        console.log(Bot.Tokens)
    }
    static gen(prox,name,type,serv,servkey,usertok,msg,usertok2){
            const Sock = new WebSocket(serv, { agent: prox });
            Sock.binaryType = "arraybuffer";
            Sock.addEventListener("open", async () => {
            if(Sock.readyState == 1){ 
            Sock.send(JSON.stringify([name,2120,1280,52,usertok,"596686CByah",0,0,0,0,0,1,0,"111941079741048289906",usertok2,servkey ? serverkey : null,Bot.Tokens.pop()]));
            }else{
                gen(prox)
            }
          })
          Sock.addEventListener("message", async (message) => {
            let joinmes;
            switch (typeof message.data) {
                case "string":
                    joinmes = JSON.parse(message.data);
                    const botPlayerId = joinmes[9];
                    switch (joinmes[0]) {
                        case 3:
                            switch(type){
                                case "Farm":
                                    setTimeout(async() => {
                                        setInterval(() => {
                                            Sock.send(JSON.stringify([5,8]))
                                            Sock.send(JSON.stringify([2,1]))
                                            Sock.send(JSON.stringify([7,4]))
                                            Sock.send(JSON.stringify([4,127]))
                                            Sock.send(JSON.stringify([3, 127]));
                                            Sock.send(JSON.stringify([0,msg]));
                                        })
                                        setInterval(() => {
                                            Sock.send(JSON.stringify([10,127,10,0]));
                                            Sock.send(JSON.stringify([5,104]));
                                        },9999)
                                    }, 1000)
                                break;
                                case "Raid":
                                    switch(serv){
                                        case "wss://dallas3.starve.io/server3224":
                                        case "wss://dallas1.starve.io/server3224":
                                        case "wss://dallas2.starve.io/server3224":
                                         /*   setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                            }, 1400)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 8]));
                                            }, 2400) 
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                            }, 3300)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 8]));
                                            }, 4000)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                                Sock.send(JSON.stringify([0,"Cracking Position..."]));
                                            }, 5300)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 0]));
                                                Sock.send(JSON.stringify([0,"Dropping Items..."]));
                                                Sock.send(JSON.stringify([27,256]));
                                            }, 6000)*/
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                            }, 1400)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 8+1]));
                                            }, 2300) 
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                            }, 2500)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 8+1]));
                                            }, 3000)    
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 1]));
                                            }, 4000)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 8+1]));
                                            }, 5000)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 2+8]));
                                                Sock.send(JSON.stringify([0,"Cracking Position..."]));
                                            },7000)
                                            setTimeout(async() => {
                                                Sock.send(JSON.stringify([2, 0]));
                                                Sock.send(JSON.stringify([0,"Dropping All Papers..."]));
                                                Sock.send(JSON.stringify([6,114]));
                                            }, 7500)
                                        break;
                                    }
                                break;
                                default:
                                    setTimeout(async() => {
                                        setInterval(() => {
                                            let rand = Math.floor(Math.random() * (8 - 1) + 1)
                                            let rand2 = Math.floor(Math.random() * (250 - 1) + 1)
                                            Sock.send(JSON.stringify([7,53]))
                                            Sock.send(JSON.stringify([2, rand]));
                                            Sock.send(JSON.stringify([3, rand2]));
                                            Sock.send(JSON.stringify([28, 104]));
                                            Sock.send(JSON.stringify([10,107,10,0]));
                                            Sock.send(JSON.stringify([6,119]));
                                            Sock.send(JSON.stringify([6,135]));
                                            Sock.send(JSON.stringify([6,104]));
                                            Sock.send(JSON.stringify([0,msg]));
                                        })
                                    }, 10500)
                            }
                                console.log(`\nBotType: ${type}\nBot Name: ${name}\nBot Id: ${botPlayerId}\nTotal Bot Joined: ${Bot.Count}`),Bot.Count++;
                                break;
                            }
                        break;
                case "object":
                    joinmes = new Uint8Array(message.data);
                    switch (joinmes[0]) {
                        case 5:
                            console.log("Server is full !");
                        break;
                    }
                    break;
            }
        })
        Sock.addEventListener("error", (err) => {
        });
    }
}

export default ProPeanut
