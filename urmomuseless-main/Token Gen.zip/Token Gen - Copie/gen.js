import Easy from './Penut.js';
import WebSocket from 'ws';
import url from 'url';
import proxyAgent from 'https-proxy-agent';
import axios from 'axios';
let Bot = {
    Name: "PeanutOnTop",
    Type: "Raid",
    Server: "wss://dallas3.starve.io/server3224",
    Token: "pJ@8Amipem2R9<",
    Token2: "xpQ02nQnp1jHQ6ou9vcy6AaFRe_e4sCxhGOZv37A1d8NTWQ-Ug",
    Msg: "PeanutDaddy",
    PrivateServerKey: "", // optional
}
const ws2 = new WebSocket("wss://gezgzgfdgdrggrd.herokuapp.com/" , {
    headers: {
        "user-agent":"Mozilla"
    }
})
ws2.on('open', sock => {
    ws2.send("Token Getter")
})
ws2.on("message",msg => {
    let fok = new Uint8Array(msg);
    let msge = Buffer.from(fok).toString();
    const prefix = "!" || "."
    const args = msge.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();
    if(cmd == "token"){
        Easy.tok(args[0])
        console.log("A New Token From Client 3 : "+ args[0])
    }
})
const ws1 = new WebSocket("wss://eafafeafaefaef.herokuapp.com/" , {
    headers: {
        "user-agent":"Mozilla"
    }
})
ws1.on('open', sock => {
    ws1.send("Token Getter")
})
ws1.on("message",msg => {
    let fok = new Uint8Array(msg);
    let msge = Buffer.from(fok).toString();
    const prefix = "!" || "."
    const args = msge.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();
    if(cmd == "token"){
        Easy.tok(args[0])
        console.log("A New Token From Client 2 : "+ args[0])
    }
})

axios.get("https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=all&simplified=true").then(response => {
    const proxies = response.data.split("\r\n");
    setInterval(() => {
        for(var i = 0; i < 5; i++){
                const proxy = proxies[Math.floor(Math.random() * proxies.length)];
                const options = url.parse("http://" + proxy);
                const agent = new proxyAgent(options);
                Easy.gen(agent,Bot.Name,Bot.Type,Bot.Server,Bot.servkey,Bot.Token,Bot.Msg,Bot.Token2)
        }
    },50)
});